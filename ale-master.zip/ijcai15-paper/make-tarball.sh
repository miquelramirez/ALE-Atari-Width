#!/bin/bash

tar jcvf ijcai_15.tar.bz2 *.tex *.bib *.bst
